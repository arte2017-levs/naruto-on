# 🔥 Ember

Launcher Android experimental (tema negro y naranja) para juegos Flash antiguos. Corre **Ruffle** dentro de un WebView, con controles táctiles editables, mouse virtual y **dos sesiones aisladas**. Gratuito y de código abierto.

> Estado: **v0.1, sin compilar ni probar en dispositivo.** El primer build puede necesitar pequeños arreglos.

## Compilar sin PC
1. Crea un repositorio en GitHub (desde el móvil) y sube este proyecto. Opción rápida: sube `ember-project.zip` y crea `.github/workflows/build.yml` (copia su contenido del zip); el workflow lo descomprime solo.
2. Pestaña **Actions → Build APK → Run workflow**.
3. Descarga el artefacto `ember-debug-apk`, descomprímelo e instala el APK.

## Qué hace hoy
| Función | Estado |
|---|---|
| Ruffle en WebView (URL o SWF local) | Implementado |
| Dos sesiones como pestañas dentro de la misma app, con perfiles de WebView aislados (requiere WebView reciente con perfiles; si no, se avisa y comparten cookies) | Implementado |
| Controles virtuales editables, perfil por juego/dominio | Implementado |
| Mouse virtual, sonido, teclado, marcadores, cronómetro, RAM | Implementado |
| Perfiles de rendimiento (calidad de Ruffle) | Implementado |
| Puente CORS (GET simples) para recursos de otros dominios | Experimental |
| Pestañas, historial, adelante/atrás visibles, chat por sesión | **Pendiente** |
| Modo remoto (Flash real en servidor) | Solo diseño: ver `docs/REMOTE.md` |

Si «Android System WebView» es antiguo y no soporta perfiles, las sesiones comparten cookies: la app lo avisa con ⚠. Actualízalo desde Play Store. Las dos sesiones usan el mismo perfil de controles por juego.

## Naruto Online: lo que hay que esperar
- Ruffle no cubre todo ActionScript 3; los MMORPG son su punto más débil.
- Estos juegos suelen usar **sockets TCP**. En navegador Ruffle solo puede usarlos mediante un proxy WebSocket (`socketProxy` en su configuración). Hace falta un proxy y saber el protocolo.
- Muchos recursos dependen de `crossdomain.xml`; el puente CORS ayuda en casos simples (no POST ni OPTIONS).
- Si el servidor oficial ya no existe, no hay nada que cargar. Verifica primero que tengas una URL válida.
- Plan: probar, anotar errores (`chrome://inspect` o logs) y publicar resultados reales.
