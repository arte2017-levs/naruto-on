# Modo remoto (diseño, no implementado)
Para juegos que Ruffle no ejecuta: un servidor corre un navegador con Flash real y lo transmite (WebRTC/VNC en web). Ember ya puede abrirlo, porque el WebView carga cualquier URL https y los botones envían teclas y puntero a la página.
- Necesita servidor propio y ancho de banda; no es gratis a gran escala.
- Flash Player oficial está discontinuado y es inseguro: aislar en contenedor, sin datos personales, y revisar licencias.
- Para sostenerlo gratis: cuotas por sesión, o que cada usuario aloje su propio servidor.
