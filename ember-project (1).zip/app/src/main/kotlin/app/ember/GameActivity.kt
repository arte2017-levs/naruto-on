package app.ember

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.ProfileStore
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

private class Sess(val slot: String, val web: WebView, val box: FrameLayout, val controls: ControlsView, val iso: Boolean) {
    var muted = false
}

/** Pantalla de juego única: sesiones A y B como pestañas, cada una con su WebView y su perfil aislado. */
class GameActivity : Activity() {
    private val host = "appassets.androidplatform.net"
    private val h = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.elapsedRealtime()
    private val sessions = linkedMapOf<String, Sess>()
    private var cur = ""
    private var cors = false
    private var showTimer = true
    private lateinit var stack: FrameLayout
    private lateinit var tabs: LinearLayout
    private lateinit var info: TextView
    private lateinit var soundBtn: TextView
    private lateinit var pad: View
    private lateinit var loader: WebViewAssetLoader
    private val prefs get() = getSharedPreferences("ember", 0)

    private val helperJs = """(function(){if(window.__e)return;window.__e={
k:function(n,c,kc,d){var t=document.querySelector('ruffle-player,ruffle-embed,canvas')||document.body;var e=new KeyboardEvent(d?'keydown':'keyup',{key:n,code:c,bubbles:true,cancelable:true});Object.defineProperty(e,'keyCode',{get:function(){return kc}});Object.defineProperty(e,'which',{get:function(){return kc}});t.dispatchEvent(e)},
m:function(ty,x,y){var t=document.elementFromPoint(x,y)||document.body;var o={clientX:x,clientY:y,bubbles:true,cancelable:true,button:0,buttons:ty=='down'?1:0,pointerId:1,pointerType:'mouse',isPrimary:true};t.dispatchEvent(new PointerEvent('pointer'+ty,o));t.dispatchEvent(new MouseEvent('mouse'+ty,o));if(ty=='up')t.dispatchEvent(new MouseEvent('click',o))},
v:function(x){document.querySelectorAll('ruffle-player,ruffle-embed').forEach(function(p){try{p.volume=x}catch(e){}});document.querySelectorAll('video,audio').forEach(function(m){m.muted=!x})}}})();"""

    private fun ruffleJs(q: String) = """(function(){if(window.__er)return;window.__er=1;window.RufflePlayer=window.RufflePlayer||{};window.RufflePlayer.config={publicPath:"https://$host/assets/ruffle/",quality:"$q",polyfills:true};var s=document.createElement('script');s.src="https://$host/assets/ruffle/ruffle.js";document.head.appendChild(s)})();"""

    private fun dp(x: Int) = Ui.dp(this, x)
    private fun js(w: WebView, s: String) = w.evaluateJavascript(s, null)
    private fun curWeb() = sessions[cur]?.web

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        File(filesDir, "swf").mkdirs()
        loader = WebViewAssetLoader.Builder().setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/swf/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "swf"))).build()

        val root = FrameLayout(this); root.setBackgroundColor(0xFF000000.toInt())
        stack = FrameLayout(this); root.addView(stack, FrameLayout.LayoutParams(-1, -1))

        // Mouse virtual (compartido): arrastrar mueve el puntero, toque corto = clic.
        pad = object : View(this) {
            var cx = 300f; var cy = 200f; var lx = 0f; var ly = 0f; var acc = 0f; var t = 0L
            val paint = Paint().apply { color = 0xFFFF6A00.toInt(); style = Paint.Style.STROKE; strokeWidth = 5f; isAntiAlias = true }
            fun m(ty: String) { val d = resources.displayMetrics.density; curWeb()?.let { js(it, "__e.m('$ty',${cx / d},${cy / d})") } }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; acc = 0f; t = e.eventTime }
                    MotionEvent.ACTION_MOVE -> {
                        cx = (cx + e.x - lx).coerceIn(0f, width.toFloat()); cy = (cy + e.y - ly).coerceIn(0f, height.toFloat())
                        acc += abs(e.x - lx) + abs(e.y - ly); lx = e.x; ly = e.y; m("move"); invalidate()
                    }
                    MotionEvent.ACTION_UP -> if (acc < dp(12) && e.eventTime - t < 250) { m("down"); m("up") }
                }
                return true
            }
            override fun onDraw(c: Canvas) { c.drawCircle(cx, cy, dp(10).toFloat(), paint); c.drawCircle(cx, cy, 3f, paint) }
        }
        pad.visibility = View.GONE
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))

        tabs = LinearLayout(this)
        root.addView(tabs, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(6), 0, 0) })
        info = TextView(this).apply { setTextColor(0xFFFF9A4D.toInt()); textSize = 11f; setBackgroundColor(0x990A0A0A.toInt()); setPadding(dp(8), dp(2), dp(8), dp(2)) }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(6), dp(8), 0) })

        val bar = LinearLayout(this); bar.visibility = View.GONE
        bar.background = Ui.box(this, 0xEE0A0A0A.toInt(), 26, Ui.OR, 2)
        bar.setPadding(dp(6), dp(2), dp(6), dp(2))
        fun tb(t: String, f: (TextView) -> Unit) = TextView(this).apply {
            text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt()); setOnClickListener { f(this) }
        }.also { bar.addView(it, LinearLayout.LayoutParams(dp(42), dp(42))) }
        soundBtn = tb("🔊") {
            sessions[cur]?.let { s -> s.muted = !s.muted; js(s.web, "__e.v(${if (s.muted) 0 else 1})"); it.text = if (s.muted) "🔇" else "🔊"; refreshTabs() }
        }
        tb("⌨") { curWeb()?.requestFocus(); (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).toggleSoftInput(InputMethodManager.SHOW_FORCED, 0) }
        tb("🖱") { pad.visibility = if (pad.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        tb("★") {
            val s = prefs.getStringSet("bm", emptySet())!!.toMutableSet(); curWeb()?.url?.let { s += it }
            prefs.edit().putStringSet("bm", s).apply(); Toast.makeText(this, "Marcador guardado", Toast.LENGTH_SHORT).show()
        }
        tb("⏱") { showTimer = !showTimer }
        tb("✎") { sessions[cur]?.controls?.let { c -> c.edit = !c.edit; Toast.makeText(this, if (c.edit) "Edición: arrastra; toca un botón para cambiarlo" else "Guardado", Toast.LENGTH_SHORT).show() } }
        tb("＋") { sessions[cur]?.controls?.add() }
        tb("👁") { sessions[cur]?.controls?.let { c -> c.visibility = if (c.visibility == View.VISIBLE) View.GONE else View.VISIBLE } }
        tb("⚙") {
            AlertDialog.Builder(this).setTitle("Rendimiento (se aplica al reabrir)")
                .setSingleChoiceItems(arrayOf("Ahorro", "Equilibrado", "Calidad"), prefs.getInt("perf", 1)) { d, i -> prefs.edit().putInt("perf", i).apply(); d.dismiss() }.show()
        }
        tb("↻") { curWeb()?.reload() }
        tb("✕") { closeCurrent() }
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(8) })
        root.addView(TextView(this).apply {
            text = "●"; textSize = 22f; setTextColor(Ui.OR); gravity = Gravity.CENTER
            setOnClickListener { bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.BOTTOM or Gravity.END))
        setContentView(root)

        handle(intent)
        h.post(object : Runnable {
            override fun run() {
                val mb = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024
                val s = (SystemClock.elapsedRealtime() - t0) / 1000
                info.text = "Sesión ${cur.uppercase()} · $mb MB (app)" + if (showTimer) " · %02d:%02d".format(s / 60, s % 60) else ""
                h.postDelayed(this, 2000)
            }
        })
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); setIntent(i); handle(i) }

    private fun handle(i: Intent) {
        val slot = i.getStringExtra("slot") ?: return
        start(slot, i.getStringExtra("url") ?: "", i.getStringExtra("swf"))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun start(slot: String, url: String, swf: String?) {
        sessions.remove(slot)?.let { stack.removeView(it.box); it.web.destroy() }
        val q = arrayOf("low", "medium", "high")[prefs.getInt("perf", 1)]
        cors = prefs.getBoolean("cors", false)
        val game = swf ?: (Uri.parse(url).host ?: "default")
        val web = WebView(this)
        // Aislamiento real dentro de la misma app: un perfil de WebView por sesión.
        var iso = false
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
                ProfileStore.getInstance().getOrCreateProfile("ember_$slot")
                WebViewCompat.setProfile(web, "ember_$slot"); iso = true
            }
        } catch (e: Exception) { iso = false }
        if (!iso && sessions.isNotEmpty()) Toast.makeText(this, "WebView sin perfiles: las sesiones comparten cookies", Toast.LENGTH_LONG).show()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = false; useWideViewPort = true; loadWithOverviewMode = true
            userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        web.setBackgroundColor(0xFF000000.toInt())
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(r.url)?.let { x ->
                    val mime = if (r.url.path?.endsWith(".wasm") == true) "application/wasm" else x.mimeType
                    return WebResourceResponse(mime, x.encoding, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), x.data)
                }
                return if (cors) corsFetch(slot, r) else null
            }
            override fun onPageFinished(v: WebView, u: String?) {
                js(v, helperJs)
                if (Uri.parse(u ?: "").host != host) js(v, ruffleJs(q))
            }
        }
        val controls = ControlsView(this, game) { k, d -> val (key, code, kc) = KeyMap.of(k); js(web, "__e.k('$key','$code',$kc,$d)") }
        val box = FrameLayout(this)
        box.addView(web, FrameLayout.LayoutParams(-1, -1)); box.addView(controls, FrameLayout.LayoutParams(-1, -1)); box.visibility = View.GONE
        stack.addView(box, FrameLayout.LayoutParams(-1, -1))
        sessions[slot] = Sess(slot, web, box, controls, iso)
        web.loadUrl(if (swf != null) "https://$host/assets/player.html?q=$q&swf=" + java.net.URLEncoder.encode("/swf/$swf", "UTF-8") else url)
        show(slot)
    }

    private fun show(slot: String) {
        cur = slot
        val saver = prefs.getInt("perf", 1) == 0
        sessions.forEach { (k, s) ->
            s.box.visibility = if (k == slot) View.VISIBLE else View.GONE
            if (k == slot) s.web.onResume() else if (saver) s.web.onPause()
        }
        soundBtn.text = if (sessions[slot]?.muted == true) "🔇" else "🔊"
        refreshTabs()
    }

    private fun closeCurrent() {
        sessions.remove(cur)?.let { stack.removeView(it.box); it.web.destroy() }
        if (sessions.isEmpty()) finish() else show(sessions.keys.first())
    }

    private fun pill(t: String, sel: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(6), dp(12), dp(6))
        setTextColor(if (sel) 0xFF120800.toInt() else Ui.OR)
        background = Ui.box(this@GameActivity, if (sel) Ui.OR else 0xCC0A0A0A.toInt(), 16, Ui.OR, 1)
        setOnClickListener { f() }
    }

    private fun refreshTabs() {
        tabs.removeAllViews()
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) } }
        tabs.addView(pill("⌂", false) { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) }, lp())
        sessions.forEach { (k, s) -> tabs.addView(pill("Sesión ${k.uppercase()}" + (if (s.muted) " 🔇" else "") + (if (s.iso) "" else " ⚠"), k == cur) { show(k) }, lp()) }
    }

    /** Puente CORS opcional: solo GET simples. */
    private fun corsFetch(slot: String, r: WebResourceRequest): WebResourceResponse? {
        val origin = r.requestHeaders["Origin"] ?: return null
        if (r.method != "GET" || r.url.scheme != "https") return null
        return try {
            val c = URL(r.url.toString()).openConnection() as HttpURLConnection
            r.requestHeaders.forEach { (k, v) -> if (!k.equals("Origin", true)) c.setRequestProperty(k, v) }
            val ck = try { ProfileStore.getInstance().getProfile("ember_$slot")?.cookieManager?.getCookie(r.url.toString()) } catch (e: Throwable) { null }
                ?: CookieManager.getInstance().getCookie(r.url.toString())
            ck?.let { c.setRequestProperty("Cookie", it) }
            c.connectTimeout = 15000; c.readTimeout = 30000
            val code = c.responseCode
            WebResourceResponse((c.contentType ?: "application/octet-stream").substringBefore(";"), "utf-8", code, c.responseMessage ?: "OK",
                mapOf("Access-Control-Allow-Origin" to origin, "Access-Control-Allow-Credentials" to "true"),
                if (code < 400) c.inputStream else c.errorStream)
        } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onPause() { super.onPause(); sessions.values.forEach { it.web.onPause() } }
    override fun onResume() { super.onResume(); sessions.forEach { (k, s) -> if (k == cur || prefs.getInt("perf", 1) != 0) s.web.onResume() } }
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val w = curWeb()
        if (w != null && w.canGoBack()) w.goBack()
        else startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
    }
    override fun onDestroy() { super.onDestroy(); h.removeCallbacksAndMessages(null); sessions.values.forEach { it.web.destroy() }; sessions.clear() }
}
