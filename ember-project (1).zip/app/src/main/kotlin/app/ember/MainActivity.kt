package app.ember

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.webkit.WebViewFeature
import java.io.File

class MainActivity : Activity() {
    private val urls = HashMap<String, EditText>()
    private var pending = "a"
    private var lastField: EditText? = null
    private fun dp(x: Int) = Ui.dp(this, x)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Ui.BG; window.navigationBarColor = Ui.BG
        val p = getSharedPreferences("ember", 0)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(36), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(col) })

        fun tv(t: String, sz: Float, c: Int = Ui.TX, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(c); if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun card(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Ui.box(this@MainActivity, Ui.CARD, 18, Ui.LINE)
            col.addView(this, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        }
        fun btn(t: String, fill: Boolean, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (fill) 0xFF120800.toInt() else Ui.OR)
            background = if (fill) Ui.box(this@MainActivity, Ui.OR, 14) else Ui.box(this@MainActivity, 0, 14, Ui.OR, 2)
            setOnClickListener { f() }
        }

        // Cabecera
        val head = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(22), dp(20), dp(22)); background = Ui.grad(this@MainActivity, 24) }
        head.addView(tv("🔥 EMBER", 32f, 0xFF120800.toInt(), true))
        head.addView(tv("Juegos Flash en tu Android · dos sesiones en una sola app", 13f, 0xFF2A0F00.toInt()))
        col.addView(head)

        val iso = try { WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE) } catch (e: Exception) { false }
        col.addView(tv(if (iso) "✔ Sesiones aisladas: cookies y datos separados" else "⚠ Tu WebView no soporta perfiles: A y B compartirían cuenta. Actualiza «Android System WebView».",
            12f, if (iso) Ui.OR2 else 0xFFFF5A3C.toInt()).apply { setPadding(dp(4), dp(10), dp(4), 0) })

        for (s in listOf("a", "b")) {
            val c = card()
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(tv("●", 16f, Ui.OR).apply { setPadding(0, 0, dp(8), 0) })
            row.addView(tv("Sesión ${s.uppercase()}", 18f, Ui.TX, true))
            c.addView(row)
            val e = EditText(this).apply {
                hint = "https://…"; setText(p.getString("url_$s", "")); inputType = InputType.TYPE_TEXT_VARIATION_URI
                setTextColor(Ui.TX); setHintTextColor(Ui.MU); setPadding(dp(12), dp(10), dp(12), dp(10))
                background = Ui.box(this@MainActivity, Ui.BG, 12, Ui.LINE)
                setOnFocusChangeListener { _, f -> if (f) lastField = this }
            }
            urls[s] = e; if (lastField == null) lastField = e
            c.addView(e, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r2.addView(btn("▶  Abrir", true) { open(s, null) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
            r2.addView(btn("📁  SWF", false) {
                pending = s
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1)
            }, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(r2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }

        val pc = card()
        pc.addView(tv("Rendimiento", 16f, Ui.OR, true))
        val rg = RadioGroup(this)
        listOf("Ahorro (pausa la sesión oculta)", "Equilibrado", "Calidad").forEachIndexed { i, n ->
            rg.addView(RadioButton(this).apply { text = n; id = 100 + i; setTextColor(Ui.TX); buttonTintList = ColorStateList.valueOf(Ui.OR) })
        }
        rg.check(100 + p.getInt("perf", 1))
        rg.setOnCheckedChangeListener { _, id -> p.edit().putInt("perf", id - 100).apply() }
        pc.addView(rg)
        pc.addView(CheckBox(this).apply {
            text = "Puente CORS (experimental)"; setTextColor(Ui.TX); buttonTintList = ColorStateList.valueOf(Ui.OR)
            isChecked = p.getBoolean("cors", false)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("cors", v).apply() }
        })

        val bc = card()
        bc.addView(tv("Marcadores", 16f, Ui.OR, true))
        val bms = p.getStringSet("bm", emptySet())!!.sorted()
        if (bms.isEmpty()) bc.addView(tv("Aún no hay marcadores (usa ★ dentro del juego).", 13f, Ui.MU))
        bms.forEach { u -> bc.addView(tv(u, 13f, Ui.TX).apply { setPadding(0, dp(8), 0, dp(8)); setOnClickListener { lastField?.setText(u) } }) }
    }

    private fun open(slot: String, swf: String?) {
        val u = urls[slot]!!.text.toString().trim()
        if (swf == null && !u.startsWith("https://")) { Toast.makeText(this, "Introduce una URL https://", Toast.LENGTH_SHORT).show(); return }
        getSharedPreferences("ember", 0).edit().putString("url_$slot", u).apply()
        startActivity(Intent(this, GameActivity::class.java).putExtra("slot", slot).putExtra("url", u).putExtra("swf", swf))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val uri = d?.data ?: return
        val name = (uri.lastPathSegment ?: "juego.swf").substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").let { if (it.endsWith(".swf")) it else "$it.swf" }
        val dir = File(filesDir, "swf").apply { mkdirs() }
        contentResolver.openInputStream(uri)?.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
        open(pending, name)
    }
}
