package app.ember

import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

object KeyMap {
    val names = listOf("W", "A", "S", "D", "Space", "Enter", "Esc", "Shift", "Tab", "Q", "E", "R", "F", "1", "2", "3", "4")
    /** key, code, keyCode */
    fun of(n: String): Triple<String, String, Int> = when {
        n == "Space" -> Triple(" ", "Space", 32)
        n == "Enter" -> Triple("Enter", "Enter", 13)
        n == "Esc" -> Triple("Escape", "Escape", 27)
        n == "Shift" -> Triple("Shift", "ShiftLeft", 16)
        n == "Tab" -> Triple("Tab", "Tab", 9)
        n[0].isDigit() -> Triple(n, "Digit$n", n[0].code)
        else -> Triple(n.lowercase(), "Key${n.uppercase()}", n[0].uppercaseChar().code)
    }
}

/** Botones virtuales por juego. Modo edición: arrastrar, tocar para cambiar tecla/tamaño/eliminar. */
class ControlsView(c: Context, private val game: String, private val send: (String, Boolean) -> Unit) : FrameLayout(c) {
    data class B(var k: String, var x: Float, var y: Float, var s: Int)

    private val prefs = c.getSharedPreferences("ember", 0)
    private val items = mutableListOf<B>()
    var edit = false
        set(v) { field = v; rebuild() }

    init { load(); rebuild() }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun load() {
        val s = prefs.getString("ctl_$game", null)
        if (s == null) {
            items += listOf(B("W", .15f, .6f, 52), B("A", .08f, .75f, 52), B("S", .15f, .9f, 52), B("D", .22f, .75f, 52),
                B("Space", .88f, .8f, 64), B("Shift", .78f, .9f, 52), B("Enter", .92f, .55f, 48), B("Esc", .95f, .1f, 40))
        } else {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items += B(o.getString("k"), o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getInt("s"))
            }
        }
    }

    private fun save() {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("k", it.k).put("x", it.x.toDouble()).put("y", it.y.toDouble()).put("s", it.s)) }
        prefs.edit().putString("ctl_$game", a.toString()).apply()
    }

    fun add() { items += B("E", .5f, .5f, 52); save(); rebuild() }

    private fun label(k: String) = when (k) { "Space" -> "␣"; "Enter" -> "⏎"; else -> k }

    private fun rebuild() {
        removeAllViews()
        items.forEach { b -> addView(make(b), LayoutParams(dp(b.s), dp(b.s))) }
        requestLayout()
    }

    private fun make(b: B): View {
        val tv = TextView(context)
        tv.text = label(b.k); tv.gravity = Gravity.CENTER; tv.setTextColor(0xFFFFFFFF.toInt()); tv.textSize = 13f
        val bg = GradientDrawable(); bg.shape = GradientDrawable.OVAL
        bg.setColor(0x44FF6A00); bg.setStroke(dp(1), if (edit) 0xFFFFB347.toInt() else 0xCCFF6A00)
        tv.background = bg; tv.alpha = 0.7f
        var moved = false
        tv.setOnTouchListener { v, e ->
            if (!edit) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { v.alpha = 1f; send(b.k, true) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.alpha = 0.7f; send(b.k, false) }
                }
            } else {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> moved = false
                    MotionEvent.ACTION_MOVE -> {
                        val loc = IntArray(2); getLocationOnScreen(loc)
                        b.x = ((e.rawX - loc[0]) / width).coerceIn(.03f, .97f)
                        b.y = ((e.rawY - loc[1]) / height).coerceIn(.05f, .95f)
                        moved = true; requestLayout()
                    }
                    MotionEvent.ACTION_UP -> { if (moved) save() else dialog(b) }
                }
            }
            true
        }
        return tv
    }

    private fun dialog(b: B) {
        AlertDialog.Builder(context).setTitle("Botón ${b.k}")
            .setItems(arrayOf("Cambiar tecla", "Más grande", "Más pequeño", "Eliminar")) { _, i ->
                when (i) {
                    0 -> AlertDialog.Builder(context).setItems(KeyMap.names.toTypedArray()) { _, j -> b.k = KeyMap.names[j]; save(); rebuild() }.show()
                    1 -> { b.s = (b.s + 8).coerceAtMost(110); save(); rebuild() }
                    2 -> { b.s = (b.s - 8).coerceAtLeast(30); save(); rebuild() }
                    3 -> { items.remove(b); save(); rebuild() }
                }
            }.show()
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l; val h = b - t
        for (i in 0 until childCount) {
            val v = getChildAt(i); val bt = items[i]; val s = dp(bt.s)
            val cx = (bt.x * w).toInt(); val cy = (bt.y * h).toInt()
            v.measure(MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(s, MeasureSpec.EXACTLY))
            v.layout(cx - s / 2, cy - s / 2, cx + s / 2, cy + s / 2)
        }
    }
}
