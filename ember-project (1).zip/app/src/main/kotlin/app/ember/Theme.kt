package app.ember

import android.content.Context
import android.graphics.drawable.GradientDrawable

/** Paleta negro + naranja. */
object Ui {
    val BG = 0xFF0A0A0A.toInt()
    val CARD = 0xFF17120E.toInt()
    val OR = 0xFFFF6A00.toInt()
    val OR2 = 0xFFFFB347.toInt()
    val TX = 0xFFF5EDE6.toInt()
    val MU = 0xFF9A8878.toInt()
    val LINE = 0xFF4A2A12.toInt()

    fun dp(c: Context, x: Int) = (x * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(c, r).toFloat(); if (stroke != 0) setStroke(dp(c, sw), stroke)
    }

    fun grad(c: Context, r: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFF6A00.toInt(), 0xFFB52E00.toInt())).apply {
        cornerRadius = dp(c, r).toFloat()
    }
}
