# Flash Game Launcher (base Android)

Plantilla inicial de un launcher Android con WebView, navegación HTTP(S), modo pantalla completa, zoom del navegador y controles táctiles superpuestos.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK 35

## Abrir
1. Descarga/clona el repositorio.
2. Abre la carpeta en Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta en un dispositivo Android.

## Flash / Ruffle
Adobe Flash Player dejó de estar soportado por los navegadores modernos. Este proyecto **no incluye Adobe Flash**. Para SWF se debe integrar Ruffle, que es un emulador Flash basado en WebAssembly. Para una web propia, coloca la distribución web oficial de Ruffle en `app/src/main/assets/ruffle/` y crea una pantalla de reproducción que cargue el SWF. La documentación oficial explica el uso de `ruffle.js` y su API:
- https://github.com/ruffle-rs/ruffle/wiki/Using-Ruffle
- https://github.com/ruffle-rs/ruffle

La plantilla actual navega a juegos web normales; no inyecta Ruffle en páginas de terceros automáticamente. Muchos sitios bloquean iframes, y algunos juegos requieren cookies, ventanas emergentes, WebSocket, autenticación o APIs que pueden no funcionar en WebView.

## Limitaciones importantes
- La emulación Ruffle no garantiza compatibilidad con todos los SWF/ActionScript 3.
- Los controles HTML superpuestos no pueden enviar teclas directamente a un iframe de otro dominio: el navegador aplica aislamiento entre orígenes. Para soporte real de WASD/ESC por juego, se necesita cargar el juego dentro de una página controlada por la app o implementar un puente nativo seguro y específico.
- El botón de mouse es un marcador de modo táctil; un mouse virtual completo requiere una capa de puntero/cursor y traducción de eventos por juego.
- La opción de calidad es un punto de extensión. No puede forzar la calidad interna de cualquier juego; solo el propio juego o Ruffle pueden ofrecer esa opción.
- El chat que el juego dibuja en su propia interfaz se verá normalmente si el sitio carga. La app no puede leer chats internos de terceros de forma universal, especialmente si están dibujados en canvas o protegidos por origen. No intercepta ni extrae mensajes.
- La reproducción en teléfonos con poca RAM depende del juego, WebView, GPU y memoria disponible. No existe un ajuste que garantice que cualquier juego funcione en cualquier teléfono.

## Seguridad
No se habilita acceso universal a archivos locales, contenido mixto ni una interfaz JavaScript nativa expuesta a páginas desconocidas. Mantén la navegación en HTTPS y solo agrega dominios de confianza si luego implementas permisos específicos.

## Próximos pasos técnicos
1. Integrar Ruffle localmente y un selector de archivos `.swf` usando Android Storage Access Framework.
2. Crear perfiles por juego (URL, orientación, botones, escala, calidad).
3. Implementar controles por juego en una página wrapper controlada por la app.
4. Probar cada título y documentar compatibilidad individual.

## Compilación desde GitHub Actions
El workflow `.github/workflows/android.yml` compila el proyecto directamente; no necesita guardar otro ZIP dentro del repositorio. En GitHub, abre Actions y ejecuta **Build Android APK**. La APK aparecerá como artefacto de la ejecución.

## Estado de compatibilidad
Esta versión es una base WebView para páginas HTTP(S). No integra un runtime Flash compatible con Naruto Online ni garantiza que el juego supere su detección de navegador. Los controles superpuestos no pueden enviar teclas a páginas de terceros dentro de un iframe. Esta compilación corrige la base y automatiza la generación de APK; no resuelve por sí sola la compatibilidad de Naruto Online.
