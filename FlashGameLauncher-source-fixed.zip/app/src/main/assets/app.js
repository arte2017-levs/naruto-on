const $=id=>document.getElementById(id), game=$('game'), pad=$('pad');
function openGame(raw){
  let u; try{u=new URL(raw)}catch(e){$('status').textContent='Escribe una dirección válida.';return}
  if(!['https:','http:'].includes(u.protocol)){ $('status').textContent='Solo se permiten páginas HTTP/HTTPS.';return; }
  $('url').value=u.href; game.src=u.href; game.style.display='block'; document.body.classList.add('playing');
  $('homePanel').style.display='none'; $('status').textContent='Cargando '+u.hostname;
}
$('go').onclick=()=>openGame($('url').value);
$('openGame').onclick=()=>openGame($('gameUrl').value);
$('url').addEventListener('keydown',e=>{if(e.key==='Enter')openGame(e.target.value)});
$('home').onclick=()=>{game.src='about:blank';game.style.display='none';document.body.classList.remove('playing');$('homePanel').style.display='block'};
$('toggle').onclick=()=>pad.classList.toggle('hidden');
$('full').onclick=()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()};
$('quality').onchange=e=>{document.documentElement.dataset.quality=e.target.value;};
function sendKey(type,key){
  // Los eventos solo se envían al documento principal del launcher. Los iframes de otros dominios
  // aíslan sus eventos por política del navegador; para esos juegos se necesita integración específica.
  const target=document.activeElement;
  target.dispatchEvent(new KeyboardEvent(type,{key,bubbles:true,cancelable:true}));
}
document.querySelectorAll('[data-key]').forEach(b=>{
  const k=b.dataset.key;
  b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);sendKey('keydown',k)});
  ['pointerup','pointercancel','lostpointercapture'].forEach(t=>b.addEventListener(t,()=>sendKey('keyup',k)));
});
// Mouse virtual básico: alterna puntero táctil para apuntar/tocar el área del juego.
$('mouse').onclick=()=>{game.style.pointerEvents='auto';$('status').textContent='Modo táctil activo: toca el área del juego.'};
// Recupera URL guardada localmente.
