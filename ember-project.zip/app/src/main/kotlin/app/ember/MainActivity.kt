package app.ember

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var url: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("ember", 0)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        val scroll = ScrollView(this).apply { setBackgroundColor(0xFF0E0F13.toInt()); addView(col) }
        fun tv(t: String, sz: Float, c: Int = 0xFFECEEF4.toInt()) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
        col.addView(tv("🔥 Ember", 28f))
        col.addView(tv("Launcher Flash experimental. Ruffle local; sin garantías de compatibilidad con cada juego.", 13f, 0xFF8B90A3.toInt()))

        url = EditText(this).apply {
            hint = "URL del juego (https://…)"; setText(p.getString("url", "")); inputType = InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(0xFFECEEF4.toInt()); setHintTextColor(0xFF8B90A3.toInt())
        }
        col.addView(url)
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }.also { col.addView(it) }
        btn("Abrir en sesión A") { open(GameA::class.java, null) }
        btn("Abrir en sesión B (aislada)") { open(GameB::class.java, null) }
        btn("Abrir archivo SWF local") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1)
        }

        col.addView(tv("Rendimiento", 16f).apply { setPadding(0, 40, 0, 8) })
        val rg = RadioGroup(this)
        listOf("Ahorro", "Equilibrado", "Calidad").forEachIndexed { i, n ->
            rg.addView(RadioButton(this).apply { text = n; id = 100 + i; setTextColor(0xFFECEEF4.toInt()) })
        }
        rg.check(100 + p.getInt("perf", 1))
        rg.setOnCheckedChangeListener { _, id -> p.edit().putInt("perf", id - 100).apply() }
        col.addView(rg)

        col.addView(CheckBox(this).apply {
            text = "Puente CORS (experimental: GET simples de dominios cruzados)"; setTextColor(0xFFECEEF4.toInt())
            isChecked = p.getBoolean("cors", false)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("cors", v).apply() }
        })

        col.addView(tv("Marcadores", 16f).apply { setPadding(0, 40, 0, 8) })
        val bms = p.getStringSet("bm", emptySet())!!.sorted()
        if (bms.isEmpty()) col.addView(tv("Aún no hay marcadores (usa ★ dentro del juego).", 13f, 0xFF8B90A3.toInt()))
        bms.forEach { u -> col.addView(Button(this).apply { text = u; isAllCaps = false; setOnClickListener { url.setText(u) } }) }
        setContentView(scroll)
    }

    private fun open(c: Class<*>, swf: String?) {
        val u = url.text.toString().trim()
        if (swf == null && !u.startsWith("https://")) { Toast.makeText(this, "Introduce una URL https://", Toast.LENGTH_SHORT).show(); return }
        getSharedPreferences("ember", 0).edit().putString("url", u).apply()
        startActivity(Intent(this, c).putExtra("url", u).putExtra("swf", swf)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT or Intent.FLAG_ACTIVITY_MULTIPLE_TASK))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val uri = d?.data ?: return
        val name = (uri.lastPathSegment ?: "juego.swf").substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").let { if (it.endsWith(".swf")) it else "$it.swf" }
        val dir = File(filesDir, "swf").apply { mkdirs() }
        contentResolver.openInputStream(uri)?.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
        open(GameA::class.java, name)
    }
}
