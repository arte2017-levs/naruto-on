package app.ember

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Build
import android.os.Bundle
import android.os.Debug
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

class GameA : GameActivity("a")
class GameB : GameActivity("b")

open class GameActivity(private val sid: String) : Activity() {
    private lateinit var web: WebView
    private lateinit var controls: ControlsView
    private val host = "appassets.androidplatform.net"
    private val h = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.elapsedRealtime()
    private var muted = false
    private var cors = false
    private var showTimer = true

    private val helperJs = """(function(){if(window.__e)return;window.__e={
k:function(n,c,kc,d){var t=document.querySelector('ruffle-player,ruffle-embed,canvas')||document.body;var e=new KeyboardEvent(d?'keydown':'keyup',{key:n,code:c,bubbles:true,cancelable:true});Object.defineProperty(e,'keyCode',{get:function(){return kc}});Object.defineProperty(e,'which',{get:function(){return kc}});t.dispatchEvent(e)},
m:function(ty,x,y){var t=document.elementFromPoint(x,y)||document.body;var o={clientX:x,clientY:y,bubbles:true,cancelable:true,button:0,buttons:ty=='down'?1:0,pointerId:1,pointerType:'mouse',isPrimary:true};t.dispatchEvent(new PointerEvent('pointer'+ty,o));t.dispatchEvent(new MouseEvent('mouse'+ty,o));if(ty=='up')t.dispatchEvent(new MouseEvent('click',o))},
v:function(x){document.querySelectorAll('ruffle-player,ruffle-embed').forEach(function(p){try{p.volume=x}catch(e){}});document.querySelectorAll('video,audio').forEach(function(m){m.muted=!x})}}})();"""

    private fun ruffleJs(q: String) = """(function(){if(window.__er)return;window.__er=1;window.RufflePlayer=window.RufflePlayer||{};window.RufflePlayer.config={publicPath:"https://$host/assets/ruffle/",quality:"$q",polyfills:true};var s=document.createElement('script');s.src="https://$host/assets/ruffle/ruffle.js";document.head.appendChild(s)})();"""

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun js(s: String) = web.evaluateJavascript(s, null)

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(b: Bundle?) {
        // Aislamiento: datos de WebView separados por sesión (API 28+) y proceso propio (ver manifest).
        if (Build.VERSION.SDK_INT >= 28) WebView.setDataDirectorySuffix(sid)
        super.onCreate(b)
        val p = getSharedPreferences("ember", 0)
        val q = arrayOf("low", "medium", "high")[p.getInt("perf", 1)]
        cors = p.getBoolean("cors", false)
        val swf = intent.getStringExtra("swf")
        val u = intent.getStringExtra("url") ?: ""
        val game = swf ?: (android.net.Uri.parse(u).host ?: "default")
        File(filesDir, "swf").mkdirs()
        val loader = WebViewAssetLoader.Builder().setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/swf/", WebViewAssetLoader.InternalStoragePathHandler(this, File(filesDir, "swf"))).build()

        web = WebView(this)
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false; allowContentAccess = false
            useWideViewPort = true; loadWithOverviewMode = true
            userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                loader.shouldInterceptRequest(r.url)?.let { x ->
                    val mime = if (r.url.path?.endsWith(".wasm") == true) "application/wasm" else x.mimeType
                    return WebResourceResponse(mime, x.encoding, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), x.data)
                }
                return if (cors) corsFetch(r) else null
            }
            override fun onPageFinished(v: WebView, url: String?) {
                js(helperJs)
                if (android.net.Uri.parse(url ?: "").host != host) js(ruffleJs(q))
            }
        }

        val root = FrameLayout(this); root.setBackgroundColor(0xFF000000.toInt())
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        controls = ControlsView(this, game) { k, d ->
            val (key, code, kc) = KeyMap.of(k)
            js("__e.k('$key','$code',$kc,$d)")
        }
        root.addView(controls, FrameLayout.LayoutParams(-1, -1))

        // Mouse virtual: arrastrar mueve el puntero, toque corto = clic.
        val pad = object : View(this) {
            var cx = 300f; var cy = 200f; var lx = 0f; var ly = 0f; var acc = 0f; var t = 0L
            val paint = Paint().apply { color = 0xCCFF7A3D.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f; isAntiAlias = true }
            fun m(ty: String) { val d = resources.displayMetrics.density; js("__e.m('$ty',${cx / d},${cy / d})") }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; acc = 0f; t = e.eventTime }
                    MotionEvent.ACTION_MOVE -> {
                        cx = (cx + e.x - lx).coerceIn(0f, width.toFloat()); cy = (cy + e.y - ly).coerceIn(0f, height.toFloat())
                        acc += abs(e.x - lx) + abs(e.y - ly); lx = e.x; ly = e.y; m("move"); invalidate()
                    }
                    MotionEvent.ACTION_UP -> if (acc < dp(12) && e.eventTime - t < 250) { m("down"); m("up") }
                }
                return true
            }
            override fun onDraw(c: Canvas) { c.drawCircle(cx, cy, dp(10).toFloat(), paint) }
        }
        pad.visibility = View.GONE
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))

        val info = TextView(this); info.setTextColor(0xCCFFFFFF.toInt()); info.textSize = 11f
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(dp(8), dp(4), 0, 0) })

        val bar = LinearLayout(this); bar.visibility = View.GONE
        bar.background = android.graphics.drawable.GradientDrawable().apply { setColor(0xCC14161E.toInt()); cornerRadius = dp(24).toFloat() }
        fun tb(t: String, f: (TextView) -> Unit) = TextView(this).apply {
            text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { f(this) }
        }.also { bar.addView(it, LinearLayout.LayoutParams(dp(42), dp(42))) }
        tb("🔊") { muted = !muted; it.text = if (muted) "🔇" else "🔊"; js("__e.v(${if (muted) 0 else 1})") }
        tb("⌨") { web.requestFocus(); (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).toggleSoftInput(InputMethodManager.SHOW_FORCED, 0) }
        tb("🖱") { pad.visibility = if (pad.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        tb("★") { val s = p.getStringSet("bm", emptySet())!!.toMutableSet(); web.url?.let { s += it }; p.edit().putStringSet("bm", s).apply(); Toast.makeText(this, "Marcador guardado", Toast.LENGTH_SHORT).show() }
        tb("⏱") { showTimer = !showTimer }
        tb("✎") { controls.edit = !controls.edit; Toast.makeText(this, if (controls.edit) "Edición: arrastra; toca un botón para cambiarlo" else "Guardado", Toast.LENGTH_SHORT).show() }
        tb("＋") { controls.add() }
        tb("👁") { controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        tb("⚙") {
            AlertDialog.Builder(this).setTitle("Rendimiento (recarga el juego)")
                .setSingleChoiceItems(arrayOf("Ahorro", "Equilibrado", "Calidad"), p.getInt("perf", 1)) { d, i -> p.edit().putInt("perf", i).apply(); d.dismiss(); recreate() }.show()
        }
        tb("↻") { web.reload() }
        root.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(8) })
        val handle = TextView(this).apply { text = "●"; textSize = 20f; setTextColor(0xAAFF7A3D.toInt()); gravity = Gravity.CENTER
            setOnClickListener { bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE } }
        root.addView(handle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.BOTTOM or Gravity.END))
        setContentView(root)

        val target = if (swf != null) "https://$host/assets/player.html?q=$q&swf=" + java.net.URLEncoder.encode("/swf/$swf", "UTF-8") else u
        web.loadUrl(target)

        val tick = object : Runnable {
            override fun run() {
                val mb = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024
                val s = (SystemClock.elapsedRealtime() - t0) / 1000
                info.text = "Sesión ${sid.uppercase()} · $mb MB" + if (showTimer) " · %02d:%02d".format(s / 60, s % 60) else ""
                h.postDelayed(this, 2000)
            }
        }
        h.post(tick)
    }

    /** Puente CORS opcional: solo GET simples. Sustituye a la política de dominios cruzados de Flash. */
    private fun corsFetch(r: WebResourceRequest): WebResourceResponse? {
        val origin = r.requestHeaders["Origin"] ?: return null
        if (r.method != "GET" || r.url.scheme != "https") return null
        return try {
            val c = URL(r.url.toString()).openConnection() as HttpURLConnection
            r.requestHeaders.forEach { (k, v) -> if (!k.equals("Origin", true)) c.setRequestProperty(k, v) }
            CookieManager.getInstance().getCookie(r.url.toString())?.let { c.setRequestProperty("Cookie", it) }
            c.connectTimeout = 15000; c.readTimeout = 30000
            val code = c.responseCode
            val ct = (c.contentType ?: "application/octet-stream").substringBefore(";")
            WebResourceResponse(ct, "utf-8", code, c.responseMessage ?: "OK",
                mapOf("Access-Control-Allow-Origin" to origin, "Access-Control-Allow-Credentials" to "true"),
                if (code < 400) c.inputStream else c.errorStream)
        } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(f: Boolean) {
        super.onWindowFocusChanged(f)
        if (f) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }
    override fun onPause() { super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); web.onResume() }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onDestroy() {
        super.onDestroy(); h.removeCallbacksAndMessages(null); web.destroy()
        if (isFinishing) android.os.Process.killProcess(android.os.Process.myPid()) // libera toda la RAM de la sesión
    }
}
